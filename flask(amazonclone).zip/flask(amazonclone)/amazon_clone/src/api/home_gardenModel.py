from api.routes import db, ma


class HomeAndGarden(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    soil = db.Column(db.String(255), nullable = False)
    flowers = db.Column(db.String(255))
    tools = db.Column(db.String(255), nullable = False)

    def __init__(self, soil, flowers, tools):
        self.soil = soil
        self.flowers = flowers
        self.tools = tools


# marshallow (ma) is used for the serialization
class HomeAndGardenSchema(ma.Schema):
    class Meta:
        fields = ("id", "soil", "flowers", "tools")


# Object
HomeAndGarden = HomeAndGardenSchema()
HomeAndGardenSchema = HomeAndGardenSchema(many=True)

