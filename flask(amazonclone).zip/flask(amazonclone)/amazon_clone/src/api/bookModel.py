from api.routes import db, ma


#Books Table
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True,autoincrement=True)
    genre = db.Column(db.String(255), nullable = False)
    author = db.Column(db.String(255), nullable = False)
    name = db.Column(db.String(255), nullable = False, unique = True, )
    style = db.Column(db.String(255))

    def __init__(self, genre, author, style):
        self.genre = genre
        self.author = author
        self.style = style

# marshallow (ma) is used for the serialization
class BookSchema(ma.Schema):
    class Meta:
        fields = ("id","genre", "author", "style")
    

# Object
Book = BookSchema()
BookSchema = BookSchema(many=True)