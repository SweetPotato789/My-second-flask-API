from api.routes import db, ma


# Movie Model
class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    producer = db.Column(db.String(255))
    actor = db.Column(db.String(255), nullable = False)
    director = db.Column(db.String(255), nullable = False)
    length = db.Column(db.String(255), nullable = False)
    co_director = db.Column(db.String(255))
    genre = db.Column(db.String(255), nullable = False)

    def __init__(self, producer, actor, director, length, co_director, genre):
        self.genre = genre
        self.producer = producer
        self.actor = actor
        self.director = director
        self.length = length
        self.co_director = co_director

# marshallow (ma) is used for the serialization
class MovieSchema(ma.Schema):
    class Meta:
        fields = ("id", "producer", "actor", "director", "length", "co_director", "genre")
    

# Object
Movie = MovieSchema()
MovieSchema = MovieSchema(many=True)
