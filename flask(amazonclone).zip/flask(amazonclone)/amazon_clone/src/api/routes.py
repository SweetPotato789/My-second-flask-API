from flash import Flask, jsonify, request, abort
from bookModel import Book, BookSchema
from clothingModel import Clothing, ClothingSchema
from movieModel import Movie, MovieSchema
from home_garden import HomeAndGarden, HomeAndGardenSchema
from electronic import Electronic, ElectronicSchema
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres@localhost:5432/amazonclone'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
ma = Marshmallow(app)

# Book routes
@app.route('/books', methods=['POST'])
def add_book():
    # Check if the requst body contains all required keys
    if not all(key in request.json for key in ['genre', 'author', 'style', 'name']):
        abort(400, 'Missing required keys in Json payload')

    # Retrieve the data from the request body
    genre = request.json['genre']
    author = request.json['author']
    style = request.json['style']
    name = request.json['name']


    # Create a new book object and add it to the database
    my_books = Book(genre, author, style, name)
    db.session.add(my_books)
    db.session.commit()

    # Serialize and return the new book object
    return jsonify(Book.dump(my_books)), 201

# GET REQUEST for books
@app.route('/show_books', methods = ['GET'])
def get_book():
    books = Book.query.all()
    result = BookSchema.dump(books)
    return jsonify(result)

# GET REQUEST for books specified by id
@app.route('/show_books/<int:id>', methods = ['GET'])
def get_distinct_book():
    name = request.args.get('name')
    genre = request.args.get('genre')

    query = Book.query
    if name:
        query = query.filter_by(name=name)
    if genre:
        query = query.filter_by(genre=genre)

    books = Book.query.all()
    result = BookSchema.dump(books)
    return jsonify(result)

# deletes books
@app.route('/delete_books/<int:id>', methods=['DELETE'])
def delete_book(id):
    book = Book.query.get(id)
    if book:
        db.session.delete(book)
        db.session.commit()
        return jsonify({'message': 'Book has been deleted successfully'})
    else:
        abort(404, 'Book not found')



# Clothing routes 
@app.route('/clothing', methods=['POST'])
def add_clothing():
    # Check if the requst body contains all required keys
    if not all(key in request.json for key in ['pants', 'shirts', 'shoes', 'coats']):
        abort(400, 'Missing required keys in Json payload')

    # Retrieve the data from the request body
    pants = request.json['pants']
    shoes = request.json['shoes']
    shirts = request.json['shirts']
    coats = request.json['coats']


    # Create a new clothing object and add it to the database
    my_clothing = Clothing(pants, shoes, shirts, coats)
    db.session.add(my_clothing)
    db.session.commit()

    # Serialize and return the new clothing object
    return jsonify(Clothing.dump(my_clothing)), 201


# GET REQUEST for clothes
@app.route('/show_clothes', methods = ['GET'])
def get_clothing():
    clothes = Clothing.query.all()
    result = ClothingSchema.dump(clothes)
    return jsonify(result)

# deletes clothes
@app.route('/delete_clothes/<int:id>', methods=['DELETE'])
def delete_clothing(id):
    clothing = Clothing.query.get(id)
    if clothing:
        db.session.delete(clothing)
        db.session.commit()
        return jsonify({'message': 'Item has been deleted successfully'})
    else:
        abort(404, 'Item not found')



# Movie routes
@app.route('/movies', methods=['POST'])
def add_movie():
    # Check if the requst body contains all required keys
    if not all(key in request.json for key in ['director', 'actor', 'length', 'genre', 'co_director', 'producer']):
        abort(400, 'Missing required keys in Json payload')

    # Retrieve the data from the request body
    director = request.json['director']
    actor = request.json['actor']
    genre = request.json['genre']
    co_director = request.json['co_director']
    producer = request.json['producer']
    length = request.json['length']


    # Create a new movie object and add it to the database
    my_movies = Movie(genre, actor, director, co_director, producer, length)
    db.session.add(my_movies)
    db.session.commit()

    # Serialize and return the new movie object
    return jsonify(Movie.dump(my_movies)), 201


# GET REQUEST for movies
@app.route('/show_movie', methods = ['GET'])
def get_movie():
    movies = Movie.query.all()
    result = MovieSchema.dump(movies)
    return jsonify(result)

# deletes movies
@app.route('/delete_movie/<int:id>', methods=['DELETE'])
def delete_movie(id):
    movie = Movie.query.get(id)
    if movie:
        db.session.delete(movie)
        db.session.commit()
        return jsonify({'message': 'Movie has been deleted successfully'})
    else:
        abort(404, 'Movie not found')


# HomeAndGarden routes
@app.route('/homeANDgarden', methods=['POST'])
def add_homeANDgarden():
    # Check if the requst body contains all required keys
    if not all(key in request.json for key in ['soil', 'flower', 'tools']):
        abort(400, 'Missing required keys in Json payload')

    # Retrieve the data from the request body
    soil = request.json['soil']
    flower = request.json['flower']
    tools = request.json['tools']


    # Create a new home/garden object and add it to the database
    my_homeANDgarden = HomeAndGarden(soil, flower, tools)
    db.session.add(my_homeANDgarden)
    db.session.commit()

    # Serialize and return the home/garden object
    return jsonify(HomeAndGarden.dump(my_homeANDgarden)), 201


# GET REQUEST home&garden items
@app.route('/show_homeANDgarden', methods = ['GET'])
def get_homeANDgarden():
    homeANDgarden_products = HomeAndGarden.query.all()
    result = HomeAndGardenSchema.dump(homeANDgarden_products)
    return jsonify(result)


# deletes home&garden product
@app.route('/delete_homeANDgarden_products/<int:id>', methods=['DELETE'])
def delete_homeANDgarden_product(id):
    homeAndgarden = HomeAndGarden.query.get(id)
    if homeAndgarden:
        db.session.delete(homeAndgarden)
        db.session.commit()
        return jsonify({'message': 'Product has been deleted successfully'})
    else:
        abort(404, 'Product not found')

# Electronic routes
@app.route('/electronics', methods=['POST'])
def add_electronic():
    # Check if the requst body contains all required keys
    if not all(key in request.json for key in ['computers', 'tablets', 'refridegerator', 'phones']):
        abort(400, 'Missing required keys in Json payload')

    # Retrieve the data from the request body
    computers = request.json['computers']
    tablets = request.json['tablets']
    refridegerator = request.json['refridegerator']
    phones = request.json['phones']


    # Create a new electronic object and add it to the database
    my_electronics = Electronic(computers, tablets, refridegerator, phones)
    db.session.add(my_electronics)
    db.session.commit()

    # Serialize and return the new electronic object
    return jsonify(Electronic.dump(my_electronics)), 201


# GET REQUEST electronics
@app.route('/show_electronic', methods = ['GET'])
def get_electronic():
    electronics = Electronic.query.all()
    result = ElectronicSchema.dump(electronics)
    return jsonify(result)


# deletes electronic
@app.route('/delete_electronic/<int:id>', methods=['DELETE'])
def delete_electronic(id):
    electronic = Electronic.query.get(id)
    if electronic:
        db.session.delete(electronic)
        db.session.commit()
        return jsonify({'message': 'Product has been deleted successfully'})
    else:
        abort(404, 'Product not found')

