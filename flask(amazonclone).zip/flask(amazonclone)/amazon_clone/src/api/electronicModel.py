from api.routes import db, ma


# Electronic
class Electronic(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    computers = db.Column(db.String(255))
    tablets = db.Column(db.String(255))
    refrigerator = db.Column(db.String(255))
    phones = db.Column(db.String(255))

    def __init__(self, computers, tablets, refridgerator, phones):
        self.computers = computers
        self.tablets = tablets 
        self.refrigerator = refridgerator
        self.phones = phones

# marshallow (ma) is used for the serialization
class ElectronicSchema(ma.Schema):
    class Meta:
        fields = ("id", "computers", "tablets", "refridegerator", "phones")
    

# Object
Electronic = ElectronicSchema()
ElectronicSchema = ElectronicSchema(many=True)

