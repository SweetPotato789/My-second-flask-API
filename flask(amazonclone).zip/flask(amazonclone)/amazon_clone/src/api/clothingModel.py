from api.routes import db, ma   



# Clothing Table
class Clothing(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pants = db.Column(db.String(255))
    shirts = db.Column(db.String(255))
    shoes = db.Column(db.String(255))
    coats = db.Column(db.String(255))

    def __init__(self, pants, shirts, shoes, coats):
        self.pants = pants
        self.shirts = shirts
        self.shoes = shoes
        self.coats = coats

# marshallow (ma) is used for the serialization
class ClothingSchema(ma.Schema):
    class Meta:
        fields = ("id", "pants", "shirts", "shoes", "coats")


# Object
Clothing = ClothingSchema()
ClothingSchema = ClothingSchema(many=True)



